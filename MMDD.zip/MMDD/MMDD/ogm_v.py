import os
os.environ["CUDA_VISIBLE_DEVICES"]="0,1,2,3"

import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data
import torch.nn.functional as F
import numpy as np
from torchvision import transforms
from torchvision.transforms import Resize, ToTensor, Normalize
import datetime
import time
from pytorch_metric_learning import losses
import pytorch_warmup as warmup
from sklearn.metrics import roc_auc_score


import config as cfg
#from AVoiD import AVoiD_mm
from dataset_dfdc import *
from MMSwin import mySwin


def main():
    torch.manual_seed(42)
    np.random.seed(42)
    device = torch.device("cuda:0")

    #model = AVoiD_mm()
    # model = mySwin()
    model = mySwin(pretrained=True)

    # modelPath = "D:/MMDD/dfdc/model_dfdc/22000-dfdc.pth"
    # model.load_state_dict(torch.load(modelPath))
    continue_iteration = 0

    model.train()
    #model = ViViT(224, 16, 1, 4)

    model = model.to(device)

    params = model.parameters()
    optimizer = optim.AdamW(params, lr=cfg.lr, weight_decay= cfg.wd)

    criterion = nn.CrossEntropyLoss()
    softmax = nn.Softmax(dim=1)  # softmax分类函数
    relu = nn.ReLU(inplace=True)  # relu激活函数
    tanh = nn.Tanh()  # tanh函数

    #con_func = losses.ContrastiveLoss().to(device)
    #am_func = losses.ArcFaceLoss(num_classes=2, embedding_size=2)
    #criterion = AAMLoss()
    #criterion = criterion.to(device)
    #criterion = AdMSoftmaxLoss(1, 1, s=10.0, m=0.5)

    transform = transforms.Compose([
        Resize(size=(224, 224)),
        ToTensor(),
        Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    global acc;
    acc = 0

    train_loader  = get_data(transform, 'train')
    # change_Ir = [len(train_loader)*3, len(train_loader)*6]
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer=optimizer, T_max=len(train_loader)*cfg.epochs - continue_iteration)

    data_iter = iter(train_loader)
    video_seq, audio_seq, target, video_label, audio_label = next(data_iter)
    #, audio_seq, audio_label, target 
    video_seq = video_seq.to(device)
    audio_seq = audio_seq.to(device)
    target = target.to(device)
    video_label = video_label.to(device)
    audio_label = audio_label.to(device)

    start_time = time.time()
    for i in range(continue_iteration, len(train_loader)*cfg.epochs):
        try:
            video_seq, audio_seq, target, video_label, audio_label = next(data_iter)
        except:
            data_iter = iter(train_loader)
            video_seq, audio_seq, target, video_label, audio_label = next(data_iter)
            
        video_seq = video_seq.to(device)
        audio_seq = audio_seq.to(device)
        target = target.to(device, dtype = torch.float).squeeze(dim=1)
        target_ =target.to(device, dtype = torch.int)

        video_label = video_label.to(device, dtype = torch.float).squeeze(dim=1)
        audio_label = audio_label.to(device, dtype = torch.float).squeeze(dim=1)
        target = target.to(device, dtype = torch.float).squeeze(dim=1)
        # target = target.to(device, dtype = torch.float)

        model.train()

        #video_seq = torch.mean(video_seq, dim=2)
        # print(audio_seq.shape)
        # print(video_seq.shape)
        # exit()
        #cls_a = model(audio_seq)

        video_result = model(video_seq, audio_seq)
        # result, video_result, audio_result = model(video_seq, audio_seq)

        #  video_result, audio_result
        del video_seq
        del audio_seq

        loss_video = criterion(video_result, video_label)
        # loss_audio = criterion(audio_result, audio_label)
        # cro_loss = criterion(result, target)

        # cos_loss = torch.abs(torch.cosine_similarity(x, SMR_x).mean(dim=0)) + torch.abs(torch.cosine_similarity(y, SMR_y).mean(dim=0))

        #con_loss = con_func(result, target.argmax(dim=-1))
        #am_loss = am_func(result, target.argmax(dim=-1))
        # + loss_video + loss_audio

        # loss = loss_video + loss_audio + loss_final
        # loss = 0.5*cro_loss + 0.2*(loss_audio + loss_video) + 0.3*cos_loss
        loss = loss_video

        loss.backward()

        # 没有调制处理
        if cfg.modulation == 'Normal':
            # no modulation, regular optimization 不需要做任何改变
            pass
        else:
            # softmax(out_v)[i]是将对应预测的分数转化成概率分布，然后用label[i]作为索引-
            # -将对应概率分布提取出来
            # print(target_)
            # print(target_.size())
            score_v = sum([softmax(video_result)[idx][target_[idx][0]] for idx in range(video_result.size(0))])
            score_a = sum([softmax(result)[idx][target_[idx][1]] for idx in range(result.size(0))])

            # 计算视频分数和音频分数比，对应论文中的ρ
            ratio_v = score_v / score_a
			# ρ取倒数
            ratio_a = 1 / ratio_v

            """
            Below is the Eq.(10) in our CVPR paper: 
            k =
                    1 - tanh(α * ρ), if rho > 1
                    1,                     others
            coeff_u is k_t_u, where t means iteration steps and u is modality indicator, either a or v.
            """

			# ratio_v大于1直接用，在0到1之间的话就取这个倒数。感觉这样处理的原因是并不知道视频或者音频哪个预测分数比较大  --ykg
            # coeff_a/v对应代码中的k

            if ratio_v > 1:
                coeff_v = 1 - tanh(cfg.alpha * relu(ratio_v))
                coeff_a = 1
            else:
                coeff_a = 1 - tanh(cfg.alpha * relu(ratio_a))
                coeff_v = 1

            # 保证调制开始位置和结束位置把epoch(这里是i)夹住
            if cfg.modulation_starts <= i <= cfg.modulation_ends:  # bug fixed
				# 遍历model所有的参数和参数名字
                for name, parms in model.named_parameters():

                    # print(len(parms.grad.size()), name, parms.grad.size())
                    # print(name)

                    layer = str(name).split('.')[0]
                    # print(name, end="  ")
                    # print(layer)

					# 音频
                    # if 'audio' in layer and len(parms.grad.size()) == 2:
                    if type(parms.grad) != type(None):
                        if 'audio' in layer:

                            # print("audio:   ", name)
                            # print(type(parms.grad))
                            
                            if cfg.modulation == 'OGM_GE':  # bug fixed
                            	# 对应的是GE的优化部分
                                # 对应的梯度下降是更新迭代的公式：θ(n+1)=θ(n)-ηkg(θ)
                                # 创建一个和parms.grad形状相同，元素服从均值为0，标准差为parms.grad的标准差加上一个很小的数的正态分布的张量。
                                parms.grad = parms.grad * coeff_a + \
                                    torch.zeros_like(parms.grad).normal_(0, parms.grad.std().item() + 1e-8)
                            elif cfg.modulation == 'OGM':
                                parms.grad *= coeff_a

                        # 视频
                        # if 'video' in layer and len(parms.grad.size()) == 2:
                        if 'video' in layer or 'visual' in layer:

                            # print("video:   ", name)
                            # print(type(parms.grad))

                            if cfg.modulation == 'OGM_GE':  # bug fixed
                                parms.grad = parms.grad * coeff_v + \
                                    torch.zeros_like(parms.grad).normal_(0, parms.grad.std().item() + 1e-8)
                            elif cfg.modulation == 'OGM':
                                parms.grad *= coeff_v
                # print("111")
                # a = input()
            else:
                pass


            # print("end")
            # a = input()

        optimizer.step()
        optimizer.zero_grad()
        scheduler.step()
        # with warmup_scheduler.dampening():
        #     scheduler.step()

        #print(optimizer.state_dict()['param_groups'][0]['lr'])


        if (i+1) % cfg.print_freq == 0:
            # target_all = []
            # result_all = []
            video_result = F.softmax(video_result, dim=1)

            # for idx in range(target.size(0)):
            #     target_all.append(target[idx].cpu().detach().numpy())
            #     result_all.append(result[idx].cpu().detach().numpy())

            video_result = video_result.argmax(dim=-1)
            video_label = video_label.argmax(dim=-1)

            acc = calc_accuracy(video_result, video_label)
            #auc = roc_auc_score(target_all, result_all, average='weighted')

            et = time.time() - start_time
            et = str(datetime.timedelta(seconds=et))[:-7]
            log = "Elapsed [{}], Iteration [{}/{}]".format(et, i+1, len(train_loader)*cfg.epochs)
            # log += ", Loss_video: {:.4f}".format(loss_video.item())
            # log += ", Loss_audio: {:.4f}".format(loss_audio.item())
            # log += ", Loss_final: {:.4f}".format(loss_final.item())
            log += ", Loss: {:.4f}".format(loss.item())
            log += ", Acc: {:.4f}".format(acc)
            #log += ", audio_loss: {:.4f}".format(loss_audio.item())
            #log += ", lr: {}".format(optimizer.state_dict()['param_groups'][0]['lr'])
            print(log)


        # Save model checkpoints.
        save_dir = cfg.model_path
        if (i+1) % cfg.save_model == 0:
            model_path = os.path.join( save_dir, '{}__dfdc_v.pth'.format(i+1))
            torch.save(model.state_dict(), model_path)
            print('Saved model checkpoints into {}...'.format(save_dir))


def calc_accuracy(label, target):
    batch_size = target.size(0)
    correct = 0
    for batch in range(batch_size):
        pred = label[batch].item()
        tar = target[batch].item()
        if pred == tar:
            correct += 1
    return correct / batch_size




def get_data(transform, mode='train'):
    dataset = deepfake_3d(out_dir=cfg.dataset_path, mode=mode,
                          transform=transform)
    sampler = data.RandomSampler(dataset)
    if mode == 'train':
        data_loader = data.DataLoader(dataset,
                                      batch_size=cfg.batch_size,
                                      sampler=sampler,
                                      shuffle=False,
                                      num_workers=0,
                                      pin_memory=False,
                                      drop_last=True)
                                      #collate_fn=my_collate)
    elif mode == 'test':
        data_loader = data.DataLoader(dataset,
                                      batch_size=cfg.batch_size,
                                      sampler=sampler,
                                      shuffle=False,
                                      num_workers=0,
                                      pin_memory=False,
                                      drop_last=False)
                                      #collate_fn=my_collate,

    print('"%s" dataset size: %d' % (mode, len(dataset)))
    return data_loader


if __name__ == '__main__':
    main()
