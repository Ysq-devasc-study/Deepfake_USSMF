

import os
os.environ["CUDA_VISIBLE_DEVICES"]="0,1,2,3"

from MMSwin import mySwin

import torch
import torch.nn.functional as F
import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from torchvision import transforms
import torchaudio
import torchaudio.transforms as AT

import torch
import torch.nn.functional as F
import torchaudio
import numpy as np
import cv2
from matplotlib import pyplot as plt
from torchaudio import transforms as AT
from moviepy.editor import VideoFileClip
import tempfile
import os


def draw_CAM_single_image(model, img_path, save_path,
                          resize=224, isSave=True, isShow=False):
    """
    适配你的 mySwin —— 单张图片 Grad-CAM
    输入自动扩展为 T=1 的 5D 张量: [1, 3, 1, H, W]
    """

    model.eval()

    # ---------------------------
    # 1. 读取和预处理图像
    # ---------------------------
    pil_img = Image.open(img_path).convert("RGB")

    loader = transforms.Compose([
        transforms.Resize((resize, resize)),
        transforms.ToTensor()
    ])

    img_tensor = loader(pil_img).unsqueeze(0)    # [1, 3, H, W]
    img_tensor = img_tensor.unsqueeze(2)        # → [1, 3, 1, H, W]
    device = next(model.parameters()).device
    img_tensor = img_tensor.to(device)

    # ---------------------------
    # 2. 注册 feature & gradient hook
    # ---------------------------
    features = []
    grads = []

    def forward_hook(module, inp, out):
        features.append(out)

    def backward_hook(module, grad_in, grad_out):
        grads.append(grad_out[0])

    # Hook video encoder 最后一个 block
    target_layer = model.video_encoder.layers[-1].blocks[-1]
    target_layer.register_forward_hook(forward_hook)
    target_layer.register_backward_hook(backward_hook)

    # ---------------------------
    # 3. 前向传播
    # ---------------------------
    outputs = model(img_tensor, img_tensor)   # video=img, audio=img 使结构不变
    result = outputs[0]  # 分类结果

    pred = torch.argmax(result).item()
    pred_score = result[:, pred]

    # ---------------------------
    # 4. 反向传播
    # ---------------------------
    model.zero_grad()
    pred_score.backward()

    feature_map = features[0]        # [1, 1, 7, 7, 768]
    gradient = grads[0]              # [1, 1, 7, 7, 768]

    # 转为标准格式 [B, C, T, H, W]
    feature_map = feature_map.permute(0, 4, 1, 2, 3)
    gradient = gradient.permute(0, 4, 1, 2, 3)

    # ---------------------------
    # 5. 计算 Grad-CAM 权重
    # ---------------------------
    weights = F.adaptive_avg_pool3d(gradient, (1, 1, 1))  # [1,C,1,1,1]

    cam = (weights * feature_map).sum(dim=1)  # [1, 1, H, W]
    cam = cam.squeeze(0).squeeze(0).detach().cpu().numpy()  # [H,W]

    cam = np.maximum(cam, 0)
    cam /= cam.max()

    print("feature_map:", feature_map.shape)
    print("gradient:", gradient.shape)
    print("cam:", cam.shape)

    # ---------------------------
    # 6. 绘制 CAM
    # ---------------------------
    img = cv2.imread(img_path)
    img = cv2.imread(img_path)
    if img is None:
        raise ValueError(f"cv2.imread() 读取失败，请检查路径: {img_path}")
    cam = cv2.resize(cam, (img.shape[1], img.shape[0]))
    cam = np.uint8(255 * cam)
    heatmap = cv2.applyColorMap(cam, cv2.COLORMAP_JET)

    result_img = 0.4 * heatmap + 0.6 * img

    if isSave:
        cv2.imwrite(save_path, result_img)

    if isShow:
        plt.imshow(result_img[:, :, ::-1] / 255)
        plt.axis("off")
        plt.show()

    return result_img



model = mySwin(pretrained=False)
device = torch.device("cuda:0")
modelPath = "/home/seczone/zzx/250621/MMDD/model_tifs/model/3000__tifs_new.pth"

model.load_state_dict(torch.load(modelPath, weights_only=False))
print(modelPath)

model = model.to(device)

for root, dirs, files in os.walk("/home/seczone/zzx/250621/MMDD/img"):
    for name in files:
        full_path = os.path.join(root, name)
        save_path = "/home/seczone/zzx/250621/MMDD/cam/" + name
        draw_CAM_single_image(model, full_path, save_path, resize=224, isSave=True, isShow=False)




