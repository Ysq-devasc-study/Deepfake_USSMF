import torch.nn as nn
import torch

from video_swin_transformer import SwinTransformer3D
from MMD import SwinTransformerMMD

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
pretrained_model_path = './swinT_backbone.pth'

class mySwin(nn.Module):
    def __init__(self, dim=768, num_classes=2, pretrained=True):
        super(mySwin, self).__init__()

        self.dim = dim
        self.num_classes = num_classes
        self.pretrained = pretrained

        self.video_encoder = SwinTransformer3D(patch_norm=True)
        self.audio_encoder = SwinTransformer3D(patch_norm=True)

        if self.pretrained:
            self.video_encoder.load_state_dict(torch.load(pretrained_model_path))
            self.audio_encoder.load_state_dict(torch.load(pretrained_model_path))

        self.block = SwinTransformerMMD()
        
        self.video_head = nn.Sequential(
            nn.BatchNorm1d(self.dim),
            nn.Linear(self.dim, self.num_classes),
        )

        self.audio_head = nn.Sequential(
            nn.BatchNorm1d(self.dim),
            nn.Linear(self.dim, self.num_classes),
        )

        self.final_head = nn.Sequential(
            nn.BatchNorm1d(self.dim*4),
            nn.Linear(self.dim*4, self.num_classes),
        )

        # self.final_head = nn.Linear(self.dim*4, self.num_classes, bias=False)
        # self.final_head.weight.requires_grad = False

        # self.final_head = nn.Sequential(
        #     nn.BatchNorm1d(self.dim*2),
        #     nn.Linear(self.dim*2, self.num_classes),
        # )

    def forward(self, video, audio):

        x, layer_results_x = self.video_encoder(video)
        y, layer_results_y= self.audio_encoder(audio)

        SMR_x = x.mean(dim=[2,3,4])
        SMR_y = y.mean(dim=[2,3,4])
        video_result = self.video_head(x.mean(dim=[2,3,4]))
        audio_result = self.audio_head(y.mean(dim=[2,3,4]))

        x, y = self.block(layer_results_x, layer_results_y)

        x = x.mean(dim=[2,3,4])
        y = y.mean(dim=[2,3,4])

        result = self.final_head(torch.cat((SMR_x, SMR_y, x, y), dim=-1))
        # result = self.final_head(torch.cat((x, y), dim=-1))

        return result, video_result, audio_result, SMR_x, SMR_y, x, y
        # return video_result
        # return audio_result




