import torch
from torch.utils import data
import os
import pandas as pd
# from augmentation import *
import random


from PIL import Image

import random

def pil_loader(path):
    with open(path, 'rb') as f:
        with Image.open(f) as img:
            return img.convert('RGB')
        
def single_modal_label_generate(label):
    if label == 'REAL':
        v_label = [1,0]
        a_label = [1,0]
    elif label == 'FAKE':
        p = random.random()
        if p < 0.33:
            v_label = [1,0]
            a_label = [0,1]
        elif p>= 0.33 and p < 0.66:
            v_label = [0,1]
            a_label = [1,0]
        elif p >= 0.66:
            v_label = [0,1]
            a_label = [0,1]
        else:
            print("随机数生成错误")

    return v_label, a_label

class deepfake_3d(data.Dataset):
    def __init__(self,out_dir,
                 mode='train',
                 transform=None):
        self.mode = mode
        self.transform = transform
        self.out_dir = out_dir

        # splits
        if mode == 'train':
            split = os.path.join(self.out_dir,'train_split.csv')
            video_info = pd.read_csv(split, header=None)
        elif (mode == 'test'):
            split = os.path.join(self.out_dir,'test_split.csv')
            video_info = pd.read_csv(split, header=None)
        else: raise ValueError('wrong mode')

        # get label list
        self.label_dict_encode = {}
        self.label_dict_decode = {}
        self.label_dict_encode['FAKE'] = [0,1]
        self.label_dict_decode['0'] = 'FAKE'
        self.label_dict_encode['REAL'] = [1,0]
        self.label_dict_decode['1'] = 'REAL'

        self.video_dict_encode = {}
        self.video_dict_encode['A'] = [1,0]
        self.video_dict_encode['B'] = [1,0]
        self.video_dict_encode['C'] = [0,1]
        self.video_dict_encode['D'] = [0,1]

        self.audio_dict_encode = {}
        self.audio_dict_encode['A'] = [1,0]
        self.audio_dict_encode['B'] = [0,1]
        self.audio_dict_encode['C'] = [1,0]
        self.audio_dict_encode['D'] = [0,1]

        self.video_info = video_info

    def __getitem__(self, index):

        # vpath, audiopath, label = self.video_info.iloc[index]
        vpath, audiopath, category, label = self.video_info.iloc[index]
        t_seq = []
        try:
            img_path_list = os.listdir("/home/seczone/zzx/250621/" + vpath.replace('\\','/'))
            for img in img_path_list:
                seq = pil_loader(os.path.join("/home/seczone/zzx/250621/" + vpath.replace('\\','/'),img))
                seq = self.transform(seq).unsqueeze_(0)
                t_seq.append(seq)
            t_seq = torch.cat(t_seq, dim=0)

            #(C, H, W) = t_seq[0].size()
            t_seq = t_seq.transpose(0,1)

            audio = pil_loader("/home/seczone/zzx/250621/" + audiopath.replace('\\','/'))
            audio = self.transform(audio).unsqueeze_(1)
            a_seq = torch.cat((audio, audio), dim=1)

            # fakeAVceleb
            a_seq = torch.cat((a_seq, a_seq), dim=1)
            a_seq = torch.cat((a_seq, a_seq), dim=1)

            # dfdc
            # a_seq = torch.cat((a_seq, a_seq), dim=1)
            # a_seq = torch.cat((a_seq, audio), dim=1)
            #audio = torch.unsqueeze(audio, 1)

            vid = self.encode_label(label)

            v_label, a_label = self.encode_category(category)
            # v_label, a_label = single_modal_label_generate(label)

            return t_seq, a_seq, torch.LongTensor(vid), torch.Tensor(v_label), torch.Tensor(a_label)
        except (FileNotFoundError, OSError) as e:
            print(f"警告: 跳过索引 {index}, 原因: {str(e)}")
            return None

        # return audio, torch.Tensor(a_label)

    def __len__(self):
        return len(self.video_info)

    def encode_label(self, label_name):
        return self.label_dict_encode[label_name]

    def decode_label(self, label_code):
        return self.label_dict_decode[label_code]
    
    def encode_category(self, category):
        return self.video_dict_encode[category], self.audio_dict_encode[category]