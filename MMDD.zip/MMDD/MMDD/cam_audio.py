import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
import cv2
import os
import av
import soundfile as sf
import librosa
import librosa.display
from PIL import Image
from torchvision import transforms

# 设置显卡
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3"

# 假设 MMSwin 是你本地的一个模块
from MMSwin import mySwin

def extract_audio_from_video(video_path, audio_output_path="audio.wav"):
    """
    使用 PyAV 从视频中提取音频并保存为 WAV 文件
    """
    try:
        container = av.open(video_path)
    except Exception as e:
        print(f"无法打开视频文件: {video_path}, 错误: {e}")
        return None, None

    # 寻找音频流
    try:
        audio_stream = next(s for s in container.streams if s.type == "audio")
    except StopIteration:
        print(f"警告: 视频中未发现音频流 {video_path}")
        container.close()
        return None, None

    samples = []
    sample_rate = audio_stream.codec_context.sample_rate

    for frame in container.decode(audio_stream):
        audio = frame.to_ndarray()
        # 转换为 (samples, channels)
        if audio.shape[0] < audio.shape[1]: 
            audio = audio.T
        samples.append(audio)

    container.close()

    if len(samples) == 0:
        return None, None

    audio_data = np.concatenate(samples, axis=0)
    
    # 如果是多声道，转单声道用于画图
    if len(audio_data.shape) > 1:
        audio_data = np.mean(audio_data, axis=1)

    # 保存临时wav文件 (有些库读取文件比较稳)
    sf.write(audio_output_path, audio_data, sample_rate)
    return audio_data, sample_rate

def generate_mel_spectrogram_img(audio, sr, save_path):
    """
    生成普通的梅尔频谱图并保存为图片 (作为模型的输入)
    """
    # 计算梅尔频谱
    # n_mels=128 是常用设置，可根据模型需求调整
    S = librosa.feature.melspectrogram(y=audio, sr=sr, n_mels=128, fmax=8000)
    S_dB = librosa.power_to_db(S, ref=np.max)

    # 绘图并保存，去除坐标轴，只保留内容
    plt.figure(figsize=(10, 10)) # 正方形方便resize
    plt.axis('off') # 去除坐标轴
    
    # 使用 librosa.display.specshow 或者直接 imshow
    # origin='lower' 确保低频在下方
    librosa.display.specshow(S_dB, sr=sr, fmax=8000, cmap='viridis')
    
    plt.savefig(save_path, bbox_inches='tight', pad_inches=0)
    plt.close()
    
    # 重新调整大小以确保一致性 (可选，后续transforms也会做)
    # 这一步是为了让保存在硬盘上的 "普通梅尔图" 也是可视化的
    return save_path

def draw_CAM_single_image(model, img_path, save_path, resize=224, isSave=True, isShow=False):
    """
    计算 Grad-CAM 并保存热度图
    """
    model.eval()
    
    # 1. 读取和预处理图像
    try:
        pil_img = Image.open(img_path).convert("RGB")
    except Exception as e:
        print(f"Error reading image {img_path}: {e}")
        return

    loader = transforms.Compose([
        transforms.Resize((resize, resize)),
        transforms.ToTensor()
    ])

    img_tensor = loader(pil_img).unsqueeze(0)    # [1, 3, H, W]
    img_tensor = img_tensor.unsqueeze(2)         # [1, 3, 1, H, W]
    
    device = next(model.parameters()).device
    img_tensor = img_tensor.to(device)

    # 2. 注册 Hook
    features = []
    grads = []

    def forward_hook(module, inp, out):
        features.append(out)

    def backward_hook(module, grad_in, grad_out):
        grads.append(grad_out[0])

    # 定位目标层
    target_layer = model.video_encoder.layers[-1].blocks[-1]
    
    # 注册并保留 handle 以便后续移除
    h1 = target_layer.register_forward_hook(forward_hook)
    h2 = target_layer.register_backward_hook(backward_hook)

    try:
        # 3. 前向传播
        # 注意：这里假设你希望把音频谱图当作视频帧输入给模型
        outputs = model(img_tensor, img_tensor) 
        result = outputs[0]

        pred = torch.argmax(result).item()
        pred_score = result[:, pred]

        # 4. 反向传播
        model.zero_grad()
        pred_score.backward()

        if not features or not grads:
            print(f"Warning: No gradients or features captured for {img_path}")
            return

        feature_map = features[0]        # [1, 1, 7, 7, 768] (维度视模型而定)
        gradient = grads[0]              # [1, 1, 7, 7, 768]

        # 维度变换
        if len(feature_map.shape) == 5: # [B, D, H, W, C] 常见 Swin 输出
            feature_map = feature_map.permute(0, 4, 1, 2, 3) # -> [B, C, D, H, W]
            gradient = gradient.permute(0, 4, 1, 2, 3)

        # 5. 计算 Grad-CAM
        # Global Average Pooling on gradients
        weights = F.adaptive_avg_pool3d(gradient, (1, 1, 1)) 
        
        # 加权求和
        cam = (weights * feature_map).sum(dim=1) 
        
        # 移除批次和时间维度 -> [H, W]
        cam = cam.squeeze(0).squeeze(0).detach().cpu().numpy()

        # ReLU
        cam = np.maximum(cam, 0)
        
        # 归一化
        if cam.max() != 0:
            cam /= cam.max()

        # 6. 绘制和叠加
        img = cv2.imread(img_path)
        if img is None:
            raise ValueError("cv2读取图片失败")
            
        cam_resized = cv2.resize(cam, (img.shape[1], img.shape[0]))
        cam_resized = np.uint8(255 * cam_resized)
        
        heatmap = cv2.applyColorMap(cam_resized, cv2.COLORMAP_JET)
        
        # 叠加：原图 * 0.6 + 热力图 * 0.4
        result_img = 0.4 * heatmap + 0.6 * img

        if isSave:
            cv2.imwrite(save_path, result_img)
            print(f"CAM saved: {save_path}")

    finally:
        # 关键：移除 Hook，否则下一次循环会重复添加导致报错或显存溢出
        h1.remove()
        h2.remove()

# --- 主执行流程 ---

# 1. 初始化模型
device = torch.device("cuda:0")
model = mySwin(pretrained=False)
pth_path = "/home/seczone/zzx/250621/MMDD/model_tifs/model/3000__tifs_new.pth"

print(f"Loading model from {pth_path}...")
model.load_state_dict(torch.load(pth_path, map_location=device, weights_only=False))
model = model.to(device)

# 2. 路径设置
video_root = "/home/seczone/zzx/250621/MMDD/audio"
save_root = "/home/seczone/zzx/250621/MMDD/cam_audio"
temp_audio_path = os.path.join(save_root, "temp_proc.wav")

os.makedirs(save_root, exist_ok=True)

# 3. 循环处理
for root, dirs, files in os.walk(video_root):
    for name in files:
        if name.lower().endswith((".mp4", ".avi", ".mkv")):
            video_path = os.path.join(root, name)
            
            # 定义保存文件名
            base_name = os.path.splitext(name)[0]
            mel_save_path = os.path.join(save_root, f"{base_name}_mel.jpg") # 普通梅尔图
            cam_save_path = os.path.join(save_root, f"{base_name}_cam.jpg") # CAM热度图

            print(f"Processing: {name}")
            
            try:
                # A. 提取音频
                audio, sr = extract_audio_from_video(video_path, temp_audio_path)
                
                if audio is not None:
                    # B. 生成并保存普通梅尔频谱图 (作为中间输入)
                    generate_mel_spectrogram_img(audio, sr, mel_save_path)
                    
                    # C. 将该频谱图放入模型生成 Grad-CAM
                    draw_CAM_single_image(model, mel_save_path, cam_save_path, resize=224)
                else:
                    print(f"Skipping {name}: No audio.")

            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"Error processing {name}: {e}")

# 清理临时文件
if os.path.exists(temp_audio_path):
    os.remove(temp_audio_path)

print("All Done.")