
import os
os.environ["CUDA_VISIBLE_DEVICES"]="0,1,2,3"

import torch
import torch.nn as nn
import torch.utils.data
import torch.nn.functional as F
import numpy as np
from torchvision import transforms
from torchvision.transforms import Resize, ToTensor, Normalize
import datetime
#from visdom import Visdom
from sklearn.metrics import roc_auc_score
from torchvision.models import vit_b_16
import time

from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt


import config as cfg
#from AVoiD import AVoiD_mm

# from dataset_fav import *
# from dataset_dfdc import *
from dataset_tifs import *

from MMSwin import mySwin
# from timesformer.models.vit import TimeSformer

#from augmentation import *
# from vit import Audio_ViT
#from av_vit_v2 import AV_ViT

def main():
    torch.manual_seed(42)
    np.random.seed(42)

    device = torch.device("cuda:2")

    model = mySwin(pretrained=False)

    modelPath = "/home/seczone/zzx/250621/MMDD/model_tifs/model/1500__tifs_new.pth"
    # /home/seczone/zzx/250621/dfdc/test/skfnhumwpn/00000

    model.load_state_dict(torch.load(modelPath, weights_only=False))
    print(modelPath)

    #model = nn.DataParallel(model, device_ids=[0])
    model = model.to(device)

    model.eval()

    transform = transforms.Compose([
        Resize(size=(224, 224)),
        ToTensor(),
        Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    global acc;
    acc = 0
    acc_v = 0
    acc_a = 0

    global loss;
    loss = 0
    loss_v = 0
    loss_a = 0
    criterion = nn.CrossEntropyLoss()

    test_loader  = get_data(transform, 'test')

    data_iter = iter(test_loader)

    # video_seq, audio_seq, target = next(data_iter)
    video_seq, audio_seq, target, _, _= next(data_iter)

    #, audio_seq, audio_label, target 
    video_seq = video_seq.to(device)
    audio_seq = audio_seq.to(device)
    target = target.to(device)

    # viz = Visdom()
    # viz.line([0.], [0.], win='test_acc', opts=dict(title='test_acc'))

    target_all = []
    result_all = []

    start_time = time.time()
    for i in range(len(test_loader)):
        try:
            video_seq, audio_seq, target, video_label, audio_label= next(data_iter)
        except:
            data_iter = iter(test_loader)
            video_seq, audio_seq, target, video_label, audio_label = next(data_iter)
            
        video_seq = video_seq.to(device)
        audio_seq = audio_seq.to(device)
        video_label = video_label.to(device)
        audio_label = audio_label.to(device)
        target = target.to(device, dtype = torch.float)

        
        model.eval()

        #video_seq = torch.mean(video_seq, dim=2)

        # print(audio_seq.shape)
        # print(video_seq.shape)
        # exit()


        result, video_result, audio_result, _, _, _, _ = model(video_seq, audio_seq)
        # result = model(video_seq, audio_seq)
        #, _, _, _, _
        #print(result)


        del video_seq
        del audio_seq

        # del删除后使用empty_cache()释放
        torch.cuda.empty_cache()

        # 加个损失
        # loss_video = criterion(cls_v, label_v)
        # loss_audio = criterion(cls_a, label_a)
        # loss_final = criterion(result, target)
        # loss += (loss_video + loss_audio + loss_final)

        # loss_v += loss_video
        # loss_a += loss_audio
 
        # result = F.softmax(result, dim=1)
        # for idx in range(target.size(0)):
        #     target_all.append(target[idx].cpu().detach().numpy())
        #     result_all.append(result[idx].cpu().detach().numpy())

        # result = result.argmax(dim=-1)
        # target = target.argmax(dim=-1)\

        result = F.softmax(result, dim=1)
        for idx in range(target.size(0)):
            target_all.append(target[idx].cpu().detach().numpy())
            result_all.append(result[idx].cpu().detach().numpy())

        result = result.argmax(dim=-1)
        target = target.argmax(dim=-1)

        #result_all.append(result.cpu().detach())

        acc += calc_accuracy(result, target)

        # # viz.line([acc / (i+1)], [i], win='test_acc', update='append')

        if (i+1) % (100) == 0:
            et = time.time() - start_time
            et = str(datetime.timedelta(seconds=et))[:-7]

            # auc = roc_auc_score(target_all, result_all, average='weighted')


            log = "Elapsed [{}], Iteration [{}/{}]".format(et, i+1, len(test_loader))
            # log += ", Accuracy: {:.4f}".format(acc / (i+1))

            # log += ", AUC: {:.4f}".format(auc)
            # log += ", Loss_v: {:.4f}".format(loss_v / (i+1))
            # log += ", Loss_a: {:.4f}".format(loss_a / (i+1))
            
            print(log)

    # 绘制AUC曲线
    targets_np = np.array(target_all)
    results_np = np.array(result_all)

    # 如果是 one-hot，本行会将它变成标签索引
    y_true = np.argmax(targets_np, axis=1)
    y_score = results_np  # softmax 概率

    # 计算 ROC 曲线（多分类 → micro）
    fpr, tpr, _ = roc_curve(y_true, y_score[:, 1], pos_label=1)

    roc_auc = auc(fpr, tpr)
    print("ROC-AUC =", roc_auc)

    # ---------------------------
    # 绘图
    # ---------------------------
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, lw=2, label="AUC = {:.4f}".format(roc_auc))
    plt.plot([0, 1], [0, 1], linestyle='--', lw=1, color='gray')

    plt.xlabel("False Positive Rate (FPR)")
    plt.ylabel("True Positive Rate (TPR)")
    plt.title("ROC Curve")
    plt.legend(loc="lower right")
    plt.grid(True)

    # 保存图片
    save_path = "./auc_curve2.png"
    plt.savefig(save_path, dpi=300)
    plt.close()

    print(f"AUC 曲线图已保存为 {save_path}")



    #target_all = torch.stack(target_all).view(-1, 1).cpu().detach().numpy()
    #result_all = torch.stack(result_all).view(-1, 1).cpu().detach().numpy()


    # auc = roc_auc_score(target_all, result_all, average='weighted')
    # print(auc)

    

# def my_collate(batch):
#     batch_shape = [list(item[0].shape) for item in batch]
#     min_t = min(min(batch_shape, key=lambda x:x[1])[1], 8)
#     v_seq, a_seq, target = [],[],[]
#     for item in batch:
#         v_seq.append(item[0][:,:min_t])
#         a_seq.append(item[1][:,:min_t])
#         target.append(item[2])
        
#     v_seq = [item.detach().numpy() for item in v_seq]
#     a_seq = [item.detach().numpy() for item in a_seq]

#     v_seq = torch.Tensor(np.array(v_seq))
#     a_seq = torch.Tensor(np.array(a_seq))

#     return [v_seq, a_seq, torch.LongTensor(target)]

# def calc_accuracy(label, target, threshold):
#     batch_size = target.size(0)
#     pred = 0
#     correct = 0
#     for batch in range(batch_size):
#         dist = label[batch].item()
#         tar = target[batch].item()
#         if dist < threshold:
#             pred = 0
#         else:
#             pred = 1
#         if pred == tar:
#             correct += 1
#     return correct*(1/batch_size)

def calc_accuracy(label, target):
    batch_size = target.size(0)
    correct = 0
    for batch in range(batch_size):
        pred = label[batch].item()
        tar = target[batch].item()
        if pred == tar:
            correct += 1
    return correct / batch_size

def calc_acc_new(result, target):
    result = F.softmax(result, dim=1)
    result = result.argmax(dim=-1)
    target = target.argmax(dim=-1)
    return calc_accuracy(result, target)

def collate_fn(batch):
    """过滤掉None值"""
    batch = [b for b in batch if b is not None]
    if len(batch) == 0:
        return None
    return torch.utils.data.dataloader.default_collate(batch)

def get_data(transform, mode='train'):
    dataset = deepfake_3d(out_dir=cfg.dataset_path, mode=mode,
                          transform=transform)
    sampler = data.RandomSampler(dataset)
    if mode == 'train':
        data_loader = data.DataLoader(dataset,
                                      batch_size=16,
                                      sampler=sampler,
                                      shuffle=False,
                                      num_workers=0,
                                      pin_memory=False,
                                      collate_fn=collate_fn,
                                      drop_last=True)
    elif mode == 'test':
        data_loader = data.DataLoader(dataset,
                                      batch_size=4,  # 16时显存撑不住
                                      sampler=sampler,
                                      shuffle=False,
                                      num_workers=0,
                                      collate_fn=collate_fn,
                                      pin_memory=False,
                                      drop_last=True)
    print('"%s" dataset size: %d' % (mode, len(dataset)))
    return data_loader


if __name__ == '__main__':
    main()
