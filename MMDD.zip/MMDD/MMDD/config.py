import torch
import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# default_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

default_device = torch.device("cuda")  

batch_size = 8
epochs = 100
dataset_path = "/home/seczone/zzx/250621/deepfakeTIFS"
model_path = './model_tifs/model'
img_dim = 224
lr = 1e-6
wd = 1e-4

print_freq = 200
#test_model = 20000 // batch_size * 2
save_model = 2000


modulation = "OGM"  # ['Normal', 'OGM', 'OGM_GE']
modulation_starts = 0
modulation_ends = 50
alpha = 0.3

