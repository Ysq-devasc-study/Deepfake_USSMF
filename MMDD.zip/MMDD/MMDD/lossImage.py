import numpy as np
from matplotlib import pyplot as plt

# 读取存储为txt文件的数据
def data_read(dir_path):
    with open(dir_path, "r") as f:
        raw_data = f.read()
        # 去除首尾中括号并分割
        data = raw_data.strip()[1:-1].split(", ")   
    return np.asfarray(data, float)

if __name__ == "__main__":

    train_loss_path = r"/home/seczone/zzx/250621/MMDD/model_tifs/model/loss__107772.txt"

    # 1. 读取所有数据
    all_loss = data_read(train_loss_path)
    
    # 2. 取前 100,000 个元素
    limit = 100000
    y_train_loss = all_loss[:limit]
    x_train_loss = range(len(y_train_loss))

    # 3. 计算每 100 个点的最小值 (Min Pooling)
    chunk_size = 100
    # 截断数据以确保能被100整除
    num_chunks = len(y_train_loss) // chunk_size
    y_truncated = y_train_loss[:num_chunks * chunk_size]
    
    # Reshape成 (N, 100) 然后在 axis=1 上取最小值
    y_min_values = y_truncated.reshape(-1, chunk_size).min(axis=1)
    
    # 生成对应的 x 轴坐标 (每100个点的起始位置)
    x_min_coords = np.arange(0, num_chunks * chunk_size, chunk_size)

    plt.figure(figsize=(10, 6)) # 稍微调大一点画布

    # 去除顶部和右边框框
    ax = plt.axes()
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.xlabel('iters')
    plt.ylabel('loss')
	
    # --- 绘图部分 ---
    
    # 1. 绘制原始数据 (背景，半透明，保持之前的颜色基调)
    # 使用 'tab:blue' 显式指定默认蓝色，避免因为画了两条线导致第二条线变色
    plt.plot(x_train_loss, y_train_loss, 
             linewidth=1, linestyle="solid", color='tab:blue', alpha=0.3, label="raw loss")

    # 2. 绘制每100个点的最小值 (前景，深色实线，颜色与背景一致)
    plt.plot(x_min_coords, y_min_values, 
             linewidth=1.5, linestyle="solid", color='tab:blue', alpha=1.0, label="min loss (per 100)")

    plt.legend()
    plt.title('Loss curve (Min per 100 iters)')
    
    # 保存并显示
    plt.savefig("loss_100k_min.png", dpi=300) # 提高一点清晰度
    # plt.show()